﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;


namespace PatientRecords.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Details(int id, String name = "Unknown")
        {
            ViewData["PatientId"] = id;
            ViewData["PatientName"] = name;
            return View();
        }
    }
}
